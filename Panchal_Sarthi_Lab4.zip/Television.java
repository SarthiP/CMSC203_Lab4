
/* 
 * The purpose of this class is to model a television
 * Sarthi Panchal 10/08/2020
 */

public class Television {
	
	 private String manufacturer; //The make of the TV, in this example it will be tohsiba 
	   private int screenSize;    // The screen size of the tv, in this example it will be 55
         private boolean powerOn;  // Power on tv or not 
	       private int volume;  // What the volume of the tv will be 
	         private int channel;  // What the channel of the tv will be on 

public Television() {

}
// the purpose of the constructor is to bring in information to whats inside the parameters 
public Television(String manufacturer, int screenSize) {
    this.manufacturer = manufacturer;
    this.screenSize = screenSize;
    powerOn = false;
    volume = 20;
    channel = 2;
}

public void setChannel(int channel) {
    this.channel = channel;
}

public void power() {
    this.powerOn = true;
}

void increaseVolume() {
    // Assuming max volume is 100
    if (volume != 100) {
        volume++;
    }
}

void decreaseVolume() {
    // if volume is zero can not decrement
    if (volume != 0) {
        volume--;
    }
}

public int getChannel() {
    return channel;
}

public int getVolume() {
    return volume;
}

public String getManufacturer() {
    return manufacturer;
}

public int getScreenSize() {
    return screenSize;
}

}